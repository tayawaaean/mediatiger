import React from 'react';

import {AdminNotificationPanel} from "../../../components/admin-notification-panel";

export const NotificationsTab: React.FC = () => {
  return (
     <>
      <AdminNotificationPanel />
     </>
  );
};